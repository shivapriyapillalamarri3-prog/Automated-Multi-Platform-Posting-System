"""Settings read from environment variables (never hard-coded)."""
import logging
import os
from dataclasses import dataclass
from typing import Mapping

logger = logging.getLogger(__name__)

PLATFORM_NAMES = ("bluesky", "mastodon", "discord", "matrix", "stoat")


@dataclass(frozen=True)
class Settings:
    platforms: tuple[str, ...]
    platform_timeout_seconds: float


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    env = os.environ if env is None else env

    raw = env.get("POSTING_PLATFORMS", "").strip()
    requested = [p.strip().lower() for p in raw.split(",") if p.strip()]
    unknown = [p for p in requested if p not in PLATFORM_NAMES]
    if unknown:
        logger.warning("Ignoring unknown POSTING_PLATFORMS entries: %s", ", ".join(unknown))
    selected = tuple(dict.fromkeys(p for p in requested if p in PLATFORM_NAMES))
    if raw and not selected:
        logger.warning("No valid POSTING_PLATFORMS entries; no platforms will be enabled")

    try:
        timeout = float(env.get("POSTING_TIMEOUT_SECONDS", "30"))
        if not 1 <= timeout <= 120:
            raise ValueError
    except ValueError:
        logger.warning("Invalid POSTING_TIMEOUT_SECONDS; using 30")
        timeout = 30.0

    # An unset variable means all platforms. A non-empty but invalid value
    # disables publishing rather than unexpectedly enabling every destination.
    platforms = selected if raw else PLATFORM_NAMES
    return Settings(platforms=platforms, platform_timeout_seconds=timeout)
