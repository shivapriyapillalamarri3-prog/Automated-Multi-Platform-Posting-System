class PlatformError(Exception):
    """A failure whose message is safe to show to API clients.

    Never put credentials, tokens, webhook URLs or raw upstream bodies in it.
    """
