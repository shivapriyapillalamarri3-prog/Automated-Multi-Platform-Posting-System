import logging
import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from fastapi import Depends, FastAPI

from app.schemas import PostingRequest, PostingResponse
from app.services.factory import build_posting_service
from app.services.posting_service import PostingService

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))

# Real environment variables win over .env (override=False) - 12-factor friendly.
load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)

app = FastAPI(
    title="Automated Posting API",
    description="Publish one short message with a single CTA link to several platforms.",
    version="2.0.0",
)


@lru_cache
def get_posting_service() -> PostingService:
    """Built lazily so a missing credential never prevents startup."""
    return build_posting_service(os.environ)


@app.get("/", include_in_schema=False)
@app.get("/health", tags=["health"])
def health(service: PostingService = Depends(get_posting_service)) -> dict:
    return {"status": "ok", "platforms": list(service.adapters)}


@app.post("/posting", response_model=PostingResponse, tags=["posting"])
async def create_posting(
    request: PostingRequest, service: PostingService = Depends(get_posting_service)
) -> PostingResponse:
    results = await service.publish_all(request.message)
    return PostingResponse(
        success=any(r["status"] == "success" for r in results), results=results
    )
