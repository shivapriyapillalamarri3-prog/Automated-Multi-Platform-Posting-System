from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timezone

import httpx

from app.errors import PlatformError


@dataclass(frozen=True)
class PublishedPost:
    posted_url: str | None
    post_id: str | None
    public_access: bool
    published_at: datetime
    note: str | None = None  # shown in `error` when the post is live but not verifiably public


def parse_timestamp(value: str | None) -> datetime:
    """Parse an ISO-8601 timestamp from a platform; fall back to 'now' (UTC)."""
    if value:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


class PlatformAdapter(ABC):
    """One adapter per platform. Implement publish(); raise on failure."""

    name: str

    def __init__(self, *, transport: httpx.AsyncBaseTransport | None = None, timeout: float = 20.0):
        self._transport = transport
        self._timeout = timeout

    def _client(self) -> httpx.AsyncClient:
        # Redirects off: never forward credentials to an unexpected host.
        return httpx.AsyncClient(
            timeout=self._timeout, transport=self._transport, follow_redirects=False
        )

    @abstractmethod
    async def publish(self, message: str) -> PublishedPost: ...


class UnconfiguredAdapter(PlatformAdapter):
    """Stands in for a platform whose credentials are missing/invalid.

    The app still starts and the platform simply reports a failed result.
    """

    def __init__(self, name: str, reason: str):
        super().__init__()
        self.name = name
        self._reason = reason

    async def publish(self, message: str) -> PublishedPost:
        raise PlatformError(self._reason)
