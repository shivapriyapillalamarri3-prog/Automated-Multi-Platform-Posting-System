import asyncio
from datetime import datetime, timezone

import httpx

from app.errors import PlatformError
from app.platforms.base import PlatformAdapter, PublishedPost
from app.validation import extract_cta_url


def build_link_facets(text: str, url: str) -> list[dict]:
    """Bluesky needs explicit facets (UTF-8 byte offsets) for clickable links."""
    index = text.find(url)
    if index < 0:
        return []
    start = len(text[:index].encode("utf-8"))
    return [{
        "index": {"byteStart": start, "byteEnd": start + len(url.encode("utf-8"))},
        "features": [{"$type": "app.bsky.richtext.facet#link", "uri": url}],
    }]


def _error_name(response: httpx.Response) -> str | None:
    try:
        return response.json().get("error")
    except (ValueError, AttributeError):
        return None


class BlueskyAdapter(PlatformAdapter):
    name = "bluesky"
    PUBLIC_API = "https://public.api.bsky.app"

    def __init__(
        self, handle: str, app_password: str, pds_url: str = "https://bsky.social", *,
        transport=None, timeout: float = 20.0, verify_attempts: int = 3, verify_delay: float = 1.5,
    ):
        super().__init__(transport=transport, timeout=timeout)
        self._handle = handle
        self._app_password = app_password
        self._pds = pds_url.rstrip("/")
        self._verify_attempts = verify_attempts
        self._verify_delay = verify_delay
        self._session: dict[str, str] | None = None
        self._lock = asyncio.Lock()

    async def _login(self, client: httpx.AsyncClient) -> None:
        response = await client.post(
            f"{self._pds}/xrpc/com.atproto.server.createSession",
            json={"identifier": self._handle, "password": self._app_password},
        )
        response.raise_for_status()
        data = response.json()
        self._session = {"access": data["accessJwt"], "refresh": data["refreshJwt"], "did": data["did"]}

    async def _refresh(self, client: httpx.AsyncClient) -> None:
        """Refresh the session; fall back to a fresh login if the refresh token is dead."""
        if self._session:
            response = await client.post(
                f"{self._pds}/xrpc/com.atproto.server.refreshSession",
                headers={"Authorization": f"Bearer {self._session['refresh']}"},
            )
            if response.status_code < 400:
                data = response.json()
                self._session = {
                    "access": data["accessJwt"], "refresh": data["refreshJwt"], "did": data["did"],
                }
                return
        await self._login(client)

    async def _create_record(self, client: httpx.AsyncClient, record: dict) -> dict:
        async def attempt() -> httpx.Response:
            return await client.post(
                f"{self._pds}/xrpc/com.atproto.repo.createRecord",
                json={"repo": self._session["did"], "collection": "app.bsky.feed.post", "record": record},
                headers={"Authorization": f"Bearer {self._session['access']}"},
            )

        response = await attempt()
        expired = response.status_code == 401 or (
            response.status_code == 400 and _error_name(response) in {"ExpiredToken", "InvalidToken"}
        )
        if expired:
            async with self._lock:
                await self._refresh(client)
            response = await attempt()
        response.raise_for_status()
        return response.json()

    async def _verify_public(self, client: httpx.AsyncClient, uri: str, text: str) -> bool:
        """Anonymous read from the public AppView (it can lag, so retry briefly)."""
        for attempt in range(self._verify_attempts):
            if attempt:
                await asyncio.sleep(self._verify_delay)
            try:
                response = await client.get(
                    f"{self.PUBLIC_API}/xrpc/app.bsky.feed.getPosts", params={"uris": uri}
                )
                response.raise_for_status()
                for post in response.json().get("posts", []):
                    if post.get("uri") == uri and post.get("record", {}).get("text") == text:
                        return True
            except (httpx.HTTPError, ValueError):
                continue
        return False

    async def publish(self, message: str) -> PublishedPost:
        url = extract_cta_url(message)
        now = datetime.now(timezone.utc)
        record = {
            "$type": "app.bsky.feed.post",
            "text": message,
            "createdAt": now.isoformat(timespec="milliseconds").replace("+00:00", "Z"),
            "facets": build_link_facets(message, url),
        }
        async with self._client() as client:
            async with self._lock:
                if self._session is None:
                    await self._login(client)
            created = await self._create_record(client, record)
            uri = created["uri"]
            public = await self._verify_public(client, uri, message)
            did = self._session["did"]

        return PublishedPost(
            posted_url=f"https://bsky.app/profile/{did}/post/{uri.rsplit('/', 1)[-1]}",
            post_id=uri,
            public_access=public,
            published_at=now,
            note=None if public else "Posted, but public visibility could not be confirmed yet",
        )
