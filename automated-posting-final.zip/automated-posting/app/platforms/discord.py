from urllib.parse import urlsplit

import httpx

from app.platforms.base import PlatformAdapter, PublishedPost, parse_timestamp

_ALLOWED_HOSTS = {"discord.com", "discordapp.com"}


def is_valid_webhook_url(url: str) -> bool:
    """Accept only Discord's HTTPS execute-webhook URL shape.

    The webhook token is part of the path and acts as a credential. Exact host
    matching is important: suffix checks would also accept lookalike domains.
    """
    try:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        port = parts.port  # Accessing this also rejects malformed ports.
    except ValueError:
        return False

    path = parts.path[:-1] if parts.path.endswith("/") else parts.path
    segments = path.split("/")
    return (
        parts.scheme.lower() == "https"
        and host in _ALLOWED_HOSTS
        and port in (None, 443)
        and parts.username is None
        and parts.password is None
        and not parts.query
        and not parts.fragment
        and len(segments) == 5
        and segments[0] == ""
        and segments[1:3] == ["api", "webhooks"]
        and segments[3].isascii()
        and segments[3].isdecimal()
        and bool(segments[4])
    )


class DiscordAdapter(PlatformAdapter):
    """Posts through an incoming webhook.

    The webhook URL is a secret: it is never logged and never put in errors.
    """

    name = "discord"

    def __init__(self, webhook_url: str, *, transport=None, timeout: float = 20.0):
        super().__init__(transport=transport, timeout=timeout)
        self._webhook = webhook_url.rstrip("/")

    async def publish(self, message: str) -> PublishedPost:
        async with self._client() as client:
            response = await client.post(
                self._webhook,
                json={"content": message, "allowed_mentions": {"parse": []}},
                params={"wait": "true"},
            )
            response.raise_for_status()
            data = response.json()

            message_id, channel_id, guild_id = data["id"], data.get("channel_id"), data.get("guild_id")
            if not (channel_id and guild_id):
                try:  # best effort: the webhook object knows its guild/channel
                    details_response = await client.get(self._webhook)
                    details_response.raise_for_status()
                    details = details_response.json()
                    channel_id = channel_id or details.get("channel_id")
                    guild_id = guild_id or details.get("guild_id")
                except (httpx.HTTPError, ValueError):
                    pass

        url = (
            f"https://discord.com/channels/{guild_id}/{channel_id}/{message_id}"
            if guild_id and channel_id else None
        )
        return PublishedPost(
            posted_url=url,
            post_id=message_id,
            public_access=False,  # Discord channel messages are not anonymously readable.
            published_at=parse_timestamp(data.get("timestamp")),
            note="Posted; Discord messages require a login to view (not publicly accessible)",
        )
