import uuid

import httpx

from app.platforms.base import PlatformAdapter, PublishedPost, parse_timestamp


class MastodonAdapter(PlatformAdapter):
    name = "mastodon"

    def __init__(self, base_url: str, access_token: str, *, transport=None, timeout: float = 20.0):
        super().__init__(transport=transport, timeout=timeout)
        self._base = base_url.rstrip("/")
        self._token = access_token

    async def _verify_public(self, client: httpx.AsyncClient, status_id: str) -> bool:
        """Anonymous read: no Authorization header is sent."""
        try:
            response = await client.get(f"{self._base}/api/v1/statuses/{status_id}")
            if response.status_code != 200:
                return False
            data = response.json()
            return data.get("id") == status_id and data.get("visibility") == "public"
        except (httpx.HTTPError, ValueError):
            return False

    async def publish(self, message: str) -> PublishedPost:
        async with self._client() as client:
            response = await client.post(
                f"{self._base}/api/v1/statuses",
                data={"status": message, "visibility": "public"},
                headers={
                    "Authorization": f"Bearer {self._token}",
                    # Mastodon accepts an idempotency key for this submission.
                    "Idempotency-Key": uuid.uuid4().hex,
                },
            )
            response.raise_for_status()
            data = response.json()
            public = await self._verify_public(client, data["id"])

        return PublishedPost(
            posted_url=data.get("url"),
            post_id=data["id"],
            public_access=public,
            published_at=parse_timestamp(data.get("created_at")),
            note=None if public else "Posted, but anonymous access could not be confirmed",
        )
