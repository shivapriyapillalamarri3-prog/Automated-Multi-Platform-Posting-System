import uuid
from datetime import datetime, timezone
from urllib.parse import quote, urlsplit

import httpx

from app.platforms.base import PlatformAdapter, PublishedPost


class MatrixAdapter(PlatformAdapter):
    name = "matrix"

    def __init__(self, homeserver_url: str, room_id: str, access_token: str, *,
                 transport=None, timeout: float = 20.0):
        super().__init__(transport=transport, timeout=timeout)
        self._server = homeserver_url.rstrip("/")
        self._room_id = room_id
        self._token = access_token

    @property
    def _room_path(self) -> str:
        return f"{self._server}/_matrix/client/v3/rooms/{quote(self._room_id, safe='')}"

    async def _room_is_world_readable(self, client: httpx.AsyncClient) -> bool:
        """Check whether non-members may read room history.

        Matrix join rules and history visibility are separate settings. A room
        does not need to allow public joins for non-members to read events when
        its history visibility is ``world_readable``.
        """
        headers = {"Authorization": f"Bearer {self._token}"}
        try:
            response = await client.get(
                f"{self._room_path}/state/m.room.history_visibility",
                headers=headers,
            )
            response.raise_for_status()
            return response.json().get("history_visibility") == "world_readable"
        except (httpx.HTTPError, ValueError):
            return False

    async def publish(self, message: str) -> PublishedPost:
        async with self._client() as client:
            response = await client.put(
                f"{self._room_path}/send/m.room.message/{uuid.uuid4().hex}",
                json={"msgtype": "m.text", "body": message},
                headers={"Authorization": f"Bearer {self._token}"},
            )
            response.raise_for_status()
            event_id = response.json()["event_id"]
            public = await self._room_is_world_readable(client)

        via = urlsplit(self._server).hostname
        link = f"https://matrix.to/#/{self._room_id}/{event_id}" + (f"?via={via}" if via else "")
        return PublishedPost(
            posted_url=link,
            post_id=event_id,
            public_access=public,
            published_at=datetime.now(timezone.utc),
            note=None if public else "Posted; room history is not world-readable to non-members",
        )
