from datetime import datetime, timezone

from app.platforms.base import PlatformAdapter, PublishedPost


class StoatAdapter(PlatformAdapter):
    name = "stoat"
    API_URL = "https://stoat.chat/api"
    WEB_URL = "https://stoat.chat"

    def __init__(self, bot_token: str, server_id: str, channel_id: str, *,
                 transport=None, timeout: float = 20.0):
        super().__init__(transport=transport, timeout=timeout)
        self._token = bot_token
        self._server_id = server_id
        self._channel_id = channel_id

    async def publish(self, message: str) -> PublishedPost:
        async with self._client() as client:
            response = await client.post(
                f"{self.API_URL}/channels/{self._channel_id}/messages",
                json={"content": message},
                headers={"X-Bot-Token": self._token},
            )
            response.raise_for_status()
            message_id = response.json()["_id"]

        return PublishedPost(
            posted_url=f"{self.WEB_URL}/server/{self._server_id}/channel/{self._channel_id}/{message_id}",
            post_id=message_id,
            public_access=False,  # This adapter does not verify public read access.
            published_at=datetime.now(timezone.utc),
            note="Posted; public access is not verified by this adapter",
        )
