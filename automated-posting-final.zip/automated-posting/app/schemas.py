from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.validation import MAX_MESSAGE_LENGTH, validate_message


class PostingRequest(BaseModel):
    # extra="forbid": platform selection is internal, so clients cannot send it.
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    message: str = Field(
        ...,
        min_length=1,
        max_length=MAX_MESSAGE_LENGTH,
        description="At most 200 characters, containing exactly one http(s) CTA link.",
        examples=["Check out our latest business platform and grow your online visibility. https://example.com"],
    )

    @field_validator("message")
    @classmethod
    def check_message(cls, value: str) -> str:
        return validate_message(value)  # raises ValueError subclass -> HTTP 422


class PlatformResult(BaseModel):
    platform: str
    status: Literal["success", "failed"]
    posted_url: str | None = None
    public_access: bool = False
    date: str | None = Field(default=None, description="UTC date, YYYY-MM-DD")
    time: str | None = Field(default=None, description="UTC time, HH:MM:SS")
    error: str | None = Field(default=None, description="Failure reason, or a note when posted but not publicly verifiable")


class PostingResponse(BaseModel):
    success: bool = Field(description="True when at least one platform published the message")
    results: list[PlatformResult]
