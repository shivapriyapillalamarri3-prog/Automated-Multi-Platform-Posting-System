"""Builds adapters from environment variables.

A platform with missing/invalid configuration becomes an UnconfiguredAdapter,
so the app always starts and that platform just reports a failed result.
"""
from typing import Callable, Mapping
from urllib.parse import urlsplit

from app.config import Settings, load_settings
from app.platforms.base import PlatformAdapter, UnconfiguredAdapter
from app.platforms.bluesky import BlueskyAdapter
from app.platforms.discord import DiscordAdapter, is_valid_webhook_url
from app.platforms.mastodon import MastodonAdapter
from app.platforms.matrix import MatrixAdapter
from app.platforms.stoat import StoatAdapter
from app.services.posting_service import PostingService


def _require(env: Mapping[str, str], keys: tuple[str, ...]) -> tuple[dict[str, str], list[str]]:
    values = {k: env.get(k, "").strip() for k in keys}
    return values, [k for k, v in values.items() if not v]


def _https(url: str) -> bool:
    """Accept an HTTPS service URL with a host and no embedded credentials."""
    try:
        parts = urlsplit(url)
        port = parts.port  # Validate the port, including its numeric range.
    except ValueError:
        return False
    return (
        parts.scheme.lower() == "https"
        and bool(parts.hostname)
        and parts.username is None
        and parts.password is None
        and not parts.query
        and not parts.fragment
        and port != 0
    )


def _bluesky(env, **kw):
    v, missing = _require(env, ("BLUESKY_HANDLE", "BLUESKY_APP_PASSWORD"))
    if missing:
        return missing, None
    pds = env.get("BLUESKY_PDS_URL", "").strip() or "https://bsky.social"
    if not _https(pds):
        return ["BLUESKY_PDS_URL (must be a valid https:// URL)"], None
    return [], BlueskyAdapter(v["BLUESKY_HANDLE"], v["BLUESKY_APP_PASSWORD"], pds, **kw)


def _mastodon(env, **kw):
    v, missing = _require(env, ("MASTODON_BASE_URL", "MASTODON_ACCESS_TOKEN"))
    if missing:
        return missing, None
    if not _https(v["MASTODON_BASE_URL"]):
        return ["MASTODON_BASE_URL (must be https://)"], None
    return [], MastodonAdapter(v["MASTODON_BASE_URL"], v["MASTODON_ACCESS_TOKEN"], **kw)


def _discord(env, **kw):
    v, missing = _require(env, ("DISCORD_WEBHOOK_URL",))
    if missing:
        return missing, None
    if not is_valid_webhook_url(v["DISCORD_WEBHOOK_URL"]):
        return ["DISCORD_WEBHOOK_URL (invalid webhook URL)"], None
    return [], DiscordAdapter(v["DISCORD_WEBHOOK_URL"], **kw)


def _matrix(env, **kw):
    keys = ("MATRIX_HOMESERVER_URL", "MATRIX_ROOM_ID", "MATRIX_ACCESS_TOKEN")
    v, missing = _require(env, keys)
    if missing:
        return missing, None
    if not _https(v["MATRIX_HOMESERVER_URL"]):
        return ["MATRIX_HOMESERVER_URL (must be https://)"], None
    return [], MatrixAdapter(v["MATRIX_HOMESERVER_URL"], v["MATRIX_ROOM_ID"], v["MATRIX_ACCESS_TOKEN"], **kw)


def _stoat(env, **kw):
    keys = ("STOAT_BOT_TOKEN", "STOAT_SERVER_ID", "STOAT_CHANNEL_ID")
    v, missing = _require(env, keys)
    if missing:
        return missing, None
    return [], StoatAdapter(v["STOAT_BOT_TOKEN"], v["STOAT_SERVER_ID"], v["STOAT_CHANNEL_ID"], **kw)


BUILDERS: dict[str, Callable] = {
    "bluesky": _bluesky, "mastodon": _mastodon, "discord": _discord,
    "matrix": _matrix, "stoat": _stoat,
}


def build_adapters(env: Mapping[str, str], settings: Settings, **adapter_kwargs) -> dict[str, PlatformAdapter]:
    adapters: dict[str, PlatformAdapter] = {}
    for name in settings.platforms:
        problems, adapter = BUILDERS[name](env, **adapter_kwargs)
        adapters[name] = adapter or UnconfiguredAdapter(
            name, f"Platform not configured: set {', '.join(problems)}"
        )
    return adapters


def build_posting_service(env: Mapping[str, str], **adapter_kwargs) -> PostingService:
    settings = load_settings(env)
    return PostingService(
        build_adapters(env, settings, **adapter_kwargs), settings.platform_timeout_seconds
    )
