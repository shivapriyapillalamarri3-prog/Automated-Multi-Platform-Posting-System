import asyncio
import logging
from datetime import timezone

import httpx

from app.errors import PlatformError
from app.platforms.base import PlatformAdapter

logger = logging.getLogger(__name__)

_HTTP_HINTS = {
    400: "rejected the request",
    401: "authentication failed (check the credentials)",
    403: "access denied (check permissions/scopes)",
    404: "resource not found (check the configured IDs/URLs)",
    422: "could not process the message",
    429: "rate limit reached",
}


def safe_error(platform: str, exc: Exception) -> str:
    """Translate any exception into a message that cannot leak secrets.

    str(exc) is deliberately not used for non-PlatformError exceptions:
    httpx embeds the full request URL (e.g. a Discord webhook token) in it.
    """
    if isinstance(exc, PlatformError):
        return str(exc)
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        hint = _HTTP_HINTS.get(code, "returned an error" if code < 500 else "is unavailable")
        return f"{platform} {hint} (HTTP {code})"
    if isinstance(exc, (httpx.TimeoutException, asyncio.TimeoutError)):
        return f"{platform} timed out"
    if isinstance(exc, httpx.InvalidURL):
        return f"{platform} URL is misconfigured"
    if isinstance(exc, httpx.TransportError):
        return f"Network error while contacting {platform}"
    if isinstance(exc, (KeyError, ValueError, TypeError, IndexError)):
        return f"Unexpected response from {platform}"
    return f"Unexpected error while posting to {platform} ({type(exc).__name__})"


class PostingService:
    def __init__(self, adapters: dict[str, PlatformAdapter], timeout_seconds: float = 30.0):
        self.adapters = adapters
        self.timeout_seconds = timeout_seconds

    async def _publish_one(self, name: str, adapter: PlatformAdapter, message: str) -> dict:
        try:
            post = await asyncio.wait_for(adapter.publish(message), self.timeout_seconds)
        except Exception as exc:  # isolate every platform failure
            error = safe_error(name, exc)
            logger.warning("Posting to %s failed: %s", name, error)
            return {
                "platform": name, "status": "failed", "posted_url": None,
                "public_access": False, "date": None, "time": None, "error": error,
            }
        moment = post.published_at.astimezone(timezone.utc)
        logger.info("Posted to %s (public_access=%s)", name, post.public_access)
        return {
            "platform": name,
            "status": "success",
            "posted_url": post.posted_url,
            "public_access": bool(post.public_access),
            "date": moment.date().isoformat(),
            "time": moment.strftime("%H:%M:%S"),
            "error": post.note,
        }

    async def publish_all(self, message: str) -> list[dict]:
        """Publish concurrently; results keep the configured platform order."""
        return list(
            await asyncio.gather(
                *(self._publish_one(n, a, message) for n, a in self.adapters.items())
            )
        )
