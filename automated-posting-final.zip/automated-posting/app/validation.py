"""Framework-independent validation of the posting message.

Kept free of pydantic so it can be unit-tested (and reused) on its own.
"""
import ipaddress
import re
from urllib.parse import urlsplit

MAX_MESSAGE_LENGTH = 200
MAX_URL_LENGTH = 2048

_SCHEME_URL = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)
# "www.example.com" without a scheme (but not the www inside https://www...)
_BARE_WWW = re.compile(r"(?<![\w/.@:-])www\.[^\s<>\"']+", re.IGNORECASE)
_TRAILING_PUNCTUATION = ".,;:!?)]}>'\""
_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
_TLD = re.compile(r"^(?:[a-z]{2,63}|xn--[a-z0-9-]{1,59})$")
_LOCAL_SUFFIXES = (".local", ".localhost", ".internal", ".lan", ".home.arpa")


class MessageValidationError(ValueError):
    """Raised with a client-friendly explanation."""


def _clean(raw: str) -> str:
    return raw.rstrip(_TRAILING_PUNCTUATION)


def find_urls(message: str) -> list[str]:
    """Return every explicit http(s) URL in the message, trailing punctuation removed."""
    return [_clean(m) for m in _SCHEME_URL.findall(message)]


def _validate_host(host: str) -> None:
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None:
        if not ip.is_global:
            raise MessageValidationError("CTA URL must not point to a private or local address")
        return

    host = host.rstrip(".").lower()
    if host == "localhost" or host.endswith(_LOCAL_SUFFIXES):
        raise MessageValidationError("CTA URL must not point to a local host")
    try:
        ascii_host = host.encode("idna").decode("ascii")
    except UnicodeError:
        raise MessageValidationError("CTA URL has an invalid hostname") from None
    labels = ascii_host.split(".")
    if (
        len(ascii_host) > 253
        or len(labels) < 2
        or not all(_LABEL.match(label) or label.startswith("xn--") for label in labels)
        or not _TLD.match(labels[-1])
    ):
        raise MessageValidationError("CTA URL has an invalid hostname")


def validate_url(url: str) -> str:
    if len(url) > MAX_URL_LENGTH:
        raise MessageValidationError("CTA URL is too long")
    try:
        parts = urlsplit(url)
        port = parts.port  # raises ValueError when out of range
    except ValueError:
        raise MessageValidationError("CTA URL is malformed (check the host and port)") from None
    if parts.scheme.lower() not in ("http", "https"):
        raise MessageValidationError("CTA URL must start with http:// or https://")
    if parts.username is not None or parts.password is not None or "@" in parts.netloc:
        raise MessageValidationError("CTA URL must not contain credentials")
    if not parts.hostname:
        raise MessageValidationError("CTA URL is missing a hostname")
    if port == 0:
        raise MessageValidationError("CTA URL has an invalid port")
    _validate_host(parts.hostname)
    return url


def validate_message(message: str) -> str:
    """Validate and return the stripped message, or raise MessageValidationError."""
    text = message.strip()
    if not text:
        raise MessageValidationError("Message must not be empty")
    if len(text) > MAX_MESSAGE_LENGTH:
        raise MessageValidationError(
            f"Message must not exceed {MAX_MESSAGE_LENGTH} characters (got {len(text)})"
        )
    urls = find_urls(text)
    bare = _BARE_WWW.findall(text)
    if bare and not urls:
        raise MessageValidationError("CTA link must start with http:// or https://")
    total = len(urls) + len(bare)
    if total != 1:
        raise MessageValidationError(
            f"Message must contain exactly one CTA link (found {total})"
        )
    validate_url(urls[0])
    return text


def extract_cta_url(message: str) -> str:
    """Return the single CTA URL of an already validated message."""
    urls = find_urls(message)
    if len(urls) != 1:
        raise MessageValidationError("Message must contain exactly one CTA link")
    return urls[0]
