# Verification record

## Automated checks

Run from the repository root:

```bash
python -m pytest -q
python -m compileall -q app tests scripts
```

The adapter tests use mocked HTTP transport. They verify request construction and response handling; they do not publish to external accounts and are not a substitute for live verification.

Local check recorded for this package:

- Python version: 3.13.5
- Test result: 87 passed
- Compilation result: successful (`compileall` returned exit code 0)
- Local API check: `GET /health` returned 200; `POST /posting` returned 200 with five isolated failed results when no platform credentials were configured
- Date checked: 19 November 2026

The GitHub Actions workflow runs the test suite on Python 3.10, 3.11 and 3.12. Remote CI results are only available after the repository is pushed and the workflow has executed.

## Live checks still required

Run `python -m scripts.live_smoke --yes` only after reviewing the configured destinations. It creates real messages.

- [ ] Save sanitized output from the live smoke run. Never include credentials or webhook URLs.
- [ ] Capture the Swagger UI request and response from `POST /posting`.
- [ ] Capture the created post in each configured platform.
- [ ] Check public accessibility using a separate account or non-member session where the platform supports it.
- [ ] Confirm each returned `posted_url` opens the intended content or channel.

Do not tick a live-check item until it has actually been completed. The mocked test suite alone does not prove that platform credentials, permissions or live endpoints are configured correctly.
