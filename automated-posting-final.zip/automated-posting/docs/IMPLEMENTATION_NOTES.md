# Implementation notes

These notes explain the decisions reflected in the current code and the trade-offs they introduce.

## Request contract

The request contains one field: `message`. The caller does not choose platforms. This follows the brief's requirement that platform selection be internal and avoids exposing infrastructure configuration as part of the public API. The deployment can still enable a subset through `POSTING_PLATFORMS`. If a non-empty value contains no supported names, the service enables no platforms instead of silently falling back to all destinations.

## Fan-out and failure handling

The service starts the enabled platform calls concurrently and collects one result per adapter. Each call has a timeout and an exception boundary. This favors partial delivery over fail-fast behavior: a temporary outage at one provider should not cancel posts to the others.

## Publishing versus visibility

An HTTP success from a provider confirms that the provider accepted the write; it does not prove that an unauthenticated user can read it. The response therefore keeps `status` separate from `public_access`. Where the adapter cannot verify public readability, it reports `false` rather than assuming success. Matrix is reported from the room's current `world_readable` history setting; that is a policy check, not an independent read using a separate guest account.

## Retries and duplicate risk

Write requests are not automatically retried. A network timeout can occur after a provider has stored the post but before the response reaches this service. Retrying such a request can create a duplicate. The API also has no client-supplied idempotency key or persistent request ledger, so an external caller retrying the whole `POST /posting` request can create another set of posts.

## Platform boundaries

Each adapter owns its provider-specific endpoint, authentication, payload and response parsing. Shared behavior—fan-out, timeouts, result formatting and safe error reporting—stays in `PostingService`. This keeps provider changes from spreading into the API route.

## Test boundary

Automated tests use `httpx.MockTransport` so they are repeatable and do not create real posts. They validate the outbound request and the code's interpretation of provider responses. They cannot prove that a real account has the required permissions, that credentials are current, or that a post is visible in the live service. Those checks belong in the manual smoke test and the submission evidence.

## Message links

For Stoat, the message ID returned by the create-message endpoint is appended to the channel path. This matches the URL construction used by Stoat's JavaScript client SDK, so the result links to the message instead of only opening the channel.
