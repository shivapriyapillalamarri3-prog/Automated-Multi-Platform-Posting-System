# Sample payloads

`posting.request.json` is a sample request. `posting.response.json` shows the expected response shape with illustrative IDs, URLs and timestamps. These values are examples, not evidence that the listed posts were published. For live proof, follow `../EVIDENCE.md` after running the service with your own platform credentials.
