"""Manual live check. Posts a REAL message to every configured platform.

    python -m scripts.live_smoke --yes
"""
import argparse
import asyncio
import json
import os
from pathlib import Path

from dotenv import load_dotenv

from app.services.factory import build_posting_service
from app.validation import MessageValidationError, validate_message


async def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--yes", action="store_true", help="confirm that real posts will be published")
    parser.add_argument("--message", default="Live smoke test of my posting API https://example.com")
    args = parser.parse_args()
    if not args.yes:
        raise SystemExit("Refusing to post without --yes")

    try:
        message = validate_message(args.message)
    except MessageValidationError as exc:
        parser.error(str(exc))

    load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)
    results = await build_posting_service(os.environ).publish_all(message)
    print(json.dumps({"success": any(r["status"] == "success" for r in results), "results": results}, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
