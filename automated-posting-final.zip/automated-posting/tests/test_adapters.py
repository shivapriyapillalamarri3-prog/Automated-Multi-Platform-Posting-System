import json
from datetime import datetime
from urllib.parse import parse_qs

import httpx
import pytest

from app.platforms.bluesky import BlueskyAdapter, build_link_facets
from app.platforms.discord import DiscordAdapter, is_valid_webhook_url
from app.platforms.mastodon import MastodonAdapter
from app.platforms.matrix import MatrixAdapter
from app.platforms.stoat import StoatAdapter

MSG = "Grow your visibility 🚀 https://example.com"
WEBHOOK = "https://discord.com/api/webhooks/111/TOKEN-SECRET"


def transport(handler):
    return httpx.MockTransport(handler)


# ---------------------------------------------------------------- Bluesky
def test_facets_use_utf8_byte_offsets_not_character_offsets():
    [facet] = build_link_facets(MSG, "https://example.com")
    start = len("Grow your visibility 🚀 ".encode())
    assert facet["index"] == {"byteStart": start, "byteEnd": start + len(b"https://example.com")}
    assert len("Grow your visibility 🚀 ") < start  # the emoji is 4 bytes, 1 character


class BskyServer:
    def __init__(self, *, expire_first=False, refresh_ok=True, indexed=True):
        self.calls, self.expire_first, self.refresh_ok, self.indexed = [], expire_first, refresh_ok, indexed
        self.logins = 0
        self.records = []

    def __call__(self, request: httpx.Request):
        path = request.url.path
        self.calls.append(path)
        if path.endswith("createSession"):
            self.logins += 1
            return httpx.Response(200, json={"accessJwt": f"a{self.logins}", "refreshJwt": "r", "did": "did:plc:abc"})
        if path.endswith("refreshSession"):
            if not self.refresh_ok:
                return httpx.Response(400, json={"error": "ExpiredToken"})
            return httpx.Response(200, json={"accessJwt": "a-refreshed", "refreshJwt": "r2", "did": "did:plc:abc"})
        if path.endswith("createRecord"):
            if self.expire_first and request.headers["authorization"] == "Bearer a1":
                return httpx.Response(400, json={"error": "ExpiredToken"})
            body = json.loads(request.content)
            self.records.append(body)
            return httpx.Response(200, json={"uri": "at://did:plc:abc/app.bsky.feed.post/3kxyz", "cid": "c"})
        if path.endswith("getPosts"):
            posts = [{"uri": "at://did:plc:abc/app.bsky.feed.post/3kxyz", "record": {"text": MSG}}]
            return httpx.Response(200, json={"posts": posts if self.indexed else []})
        return httpx.Response(404)


def bsky(server, **kw):
    return BlueskyAdapter("me.bsky.social", "pw", transport=transport(server), verify_delay=0, **kw)


async def test_bluesky_publishes_record_with_type_and_link_facet():
    server = BskyServer()
    post = await bsky(server).publish(MSG)
    record = server.records[0]["record"]
    assert record["$type"] == "app.bsky.feed.post" and record["text"] == MSG
    assert record["facets"][0]["features"][0]["uri"] == "https://example.com"
    assert post.posted_url == "https://bsky.app/profile/did:plc:abc/post/3kxyz"
    assert post.public_access is True and post.note is None
    assert isinstance(post.published_at, datetime)


async def test_bluesky_reuses_session_across_posts():
    server = BskyServer()
    adapter = bsky(server)
    await adapter.publish(MSG)
    await adapter.publish(MSG)
    assert server.logins == 1


async def test_bluesky_refreshes_expired_token_and_retries():
    server = BskyServer(expire_first=True)
    post = await bsky(server).publish(MSG)
    assert any(p.endswith("refreshSession") for p in server.calls)
    assert post.public_access is True


async def test_bluesky_relogs_in_when_refresh_token_is_dead():
    server = BskyServer(expire_first=True, refresh_ok=False)
    # after re-login the token is "a2", which the fake server accepts
    await bsky(server).publish(MSG)
    assert server.logins == 2


async def test_bluesky_reports_unindexed_post_as_not_public_after_retries():
    server = BskyServer(indexed=False)
    post = await bsky(server).publish(MSG)
    assert post.public_access is False and "could not be confirmed" in post.note
    assert sum(p.endswith("getPosts") for p in server.calls) == 3


# --------------------------------------------------------------- Mastodon
async def test_mastodon_posts_publicly_and_verifies_anonymously():
    seen = {}

    def handler(request):
        if request.method == "POST":
            seen["post_headers"] = request.headers
            seen["body"] = parse_qs(request.content.decode())
            return httpx.Response(200, json={"id": "42", "url": "https://m.example/@me/42",
                                             "created_at": "2026-11-15T10:30:00.000Z"})
        seen["get_auth"] = request.headers.get("authorization")
        return httpx.Response(200, json={"id": "42", "visibility": "public"})

    post = await MastodonAdapter("https://m.example/", "tok", transport=transport(handler)).publish(MSG)
    assert seen["body"] == {"status": [MSG], "visibility": ["public"]}
    assert seen["post_headers"]["authorization"] == "Bearer tok"
    assert seen["post_headers"]["idempotency-key"]
    assert "application/x-www-form-urlencoded" in seen["post_headers"]["content-type"]
    assert seen["get_auth"] is None  # verification is anonymous
    assert post.public_access is True and post.published_at.isoformat().startswith("2026-11-15T10:30:00")


async def test_mastodon_marks_not_public_when_anonymous_read_404s():
    def handler(request):
        if request.method == "POST":
            return httpx.Response(200, json={"id": "42", "url": "u"})
        return httpx.Response(404)

    post = await MastodonAdapter("https://m.example", "t", transport=transport(handler)).publish(MSG)
    assert post.public_access is False and post.note


# ---------------------------------------------------------------- Discord
def test_webhook_url_validation():
    assert is_valid_webhook_url(WEBHOOK)
    assert is_valid_webhook_url("https://discordapp.com/api/webhooks/123456/token")
    assert is_valid_webhook_url("https://discord.com:443/api/webhooks/123456/token")


@pytest.mark.parametrize("url", [
    "http://discord.com/api/webhooks/1/token",
    "https://evil.example/api/webhooks/1/token",
    "https://notdiscord.com/api/webhooks/1/token",
    "https://evil-discordapp.com/api/webhooks/1/token",
    "https://discord.com.attacker.test/api/webhooks/1/token",
    "https://user@discord.com/api/webhooks/1/token",
    "https://discord.com:444/api/webhooks/1/token",
    "https://discord.com:invalid/api/webhooks/1/token",
    "https://discord.com/api/webhooks/abc/token",
    "https://discord.com/api/webhooks/1/token/extra",
    "https://discord.com//api/webhooks/1/token",
    "https://discord.com/api/webhooks/١/token",
    "https://discord.com/api/webhooks/1/token?redirect=example.com",
    "https://discord.com/api/webhooks/1/token#fragment",
])
def test_webhook_url_validation_rejects_lookalikes_and_unexpected_parts(url):
    assert not is_valid_webhook_url(url)


async def test_discord_builds_message_link_and_is_not_public():
    def handler(request):
        assert request.url.params["wait"] == "true"
        body = json.loads(request.content)
        assert body["allowed_mentions"] == {"parse": []}
        return httpx.Response(200, json={"id": "9", "channel_id": "8", "guild_id": "7",
                                         "timestamp": "2026-11-15T10:30:00+00:00"})

    post = await DiscordAdapter(WEBHOOK, transport=transport(handler)).publish(MSG)
    assert post.posted_url == "https://discord.com/channels/7/8/9"
    assert post.public_access is False and "login" in post.note


async def test_discord_looks_up_guild_when_response_lacks_it():
    def handler(request):
        if request.method == "POST":
            return httpx.Response(200, json={"id": "9", "channel_id": "8"})
        return httpx.Response(200, json={"guild_id": "7", "channel_id": "8"})

    post = await DiscordAdapter(WEBHOOK, transport=transport(handler)).publish(MSG)
    assert post.posted_url == "https://discord.com/channels/7/8/9"


async def test_discord_http_error_is_raised_but_not_formatted_here():
    adapter = DiscordAdapter(WEBHOOK, transport=transport(lambda r: httpx.Response(401)))
    with pytest.raises(httpx.HTTPStatusError):
        await adapter.publish(MSG)  # PostingService sanitizes this (see test_posting_service)


# ----------------------------------------------------------------- Matrix
def matrix_handler(history="world_readable"):
    requested_paths = []

    def handler(request):
        path = request.url.raw_path.decode()
        requested_paths.append(path)
        if request.method == "PUT":
            assert "%21room" in path  # room id is URL-quoted
            return httpx.Response(200, json={"event_id": "$evt"})
        if path.endswith("m.room.history_visibility"):
            return httpx.Response(200, json={"history_visibility": history})
        return httpx.Response(404)

    handler.requested_paths = requested_paths
    return handler


async def test_matrix_world_readable_history_is_accessible_without_joining():
    # Join rule is intentionally not queried: it controls joining, not reading history.
    handler = matrix_handler(history="world_readable")
    post = await MatrixAdapter("https://matrix.org", "!room", "tok", transport=transport(handler)).publish(MSG)
    assert post.posted_url == "https://matrix.to/#/!room/$evt?via=matrix.org"
    assert post.public_access is True
    assert not any("join_rules" in path for path in handler.requested_paths)


async def test_matrix_shared_history_is_not_world_readable_even_if_room_is_publicly_joinable():
    adapter = MatrixAdapter("https://matrix.org", "!room", "tok", transport=transport(matrix_handler(history="shared")))
    post = await adapter.publish(MSG)
    assert post.public_access is False and "world-readable" in post.note


# ------------------------------------------------------------------ Stoat
async def test_stoat_posts_with_bot_token_header():
    def handler(request):
        assert request.headers["x-bot-token"] == "bot"
        assert request.url.path == "/api/channels/CH/messages"
        return httpx.Response(200, json={"_id": "M1"})

    post = await StoatAdapter("bot", "SRV", "CH", transport=transport(handler)).publish(MSG)
    assert post.post_id == "M1" and post.public_access is False
    assert post.posted_url == "https://stoat.chat/server/SRV/channel/CH/M1"
