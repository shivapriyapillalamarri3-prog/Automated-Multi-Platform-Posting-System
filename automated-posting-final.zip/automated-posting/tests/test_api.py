import pytest
from fastapi.testclient import TestClient

from app.main import app, get_posting_service
from app.services.posting_service import PostingService
from tests.test_posting_service import Fake
from app.errors import PlatformError

BODY = {"message": "Check out our platform. https://example.com"}


@pytest.fixture
def client():
    yield TestClient(app)
    app.dependency_overrides.clear()


def use(adapters):
    app.dependency_overrides[get_posting_service] = lambda: PostingService(adapters)


def test_response_matches_spec_shape_with_partial_failure(client):
    use({"a": Fake("a"), "b": Fake("b", exc=PlatformError("Authentication failed"))})
    response = client.post("/posting", json=BODY)
    assert response.status_code == 200
    data = response.json()
    assert set(data) == {"success", "results"} and data["success"] is True
    assert set(data["results"][0]) == {"platform", "status", "posted_url", "public_access", "date", "time", "error"}
    assert data["results"][1]["error"] == "Authentication failed"


def test_success_false_when_every_platform_fails(client):
    use({"a": Fake("a", exc=PlatformError("x"))})
    assert client.post("/posting", json=BODY).json()["success"] is False


@pytest.mark.parametrize("body", [
    {}, {"message": ""}, {"message": "no link"}, {"message": "A" * 201 + " https://example.com"},
    {"message": "https://a.com https://b.com"}, {**BODY, "platforms": ["bluesky"]},
])
def test_invalid_requests_return_422_and_publish_nothing(client, body):
    fake = Fake("a")
    use({"a": fake})
    assert client.post("/posting", json=body).status_code == 422


def test_app_starts_without_any_credentials(client):
    get_posting_service.cache_clear()
    assert client.get("/health").json()["status"] == "ok"
