from app.config import PLATFORM_NAMES, load_settings
from app.platforms.base import UnconfiguredAdapter
from app.services.factory import build_posting_service


async def test_app_builds_with_no_credentials_and_reports_each_platform_as_failed():
    service = build_posting_service({})
    assert list(service.adapters) == list(PLATFORM_NAMES)
    assert all(isinstance(a, UnconfiguredAdapter) for a in service.adapters.values())
    results = await service.publish_all("Hi https://example.com")
    assert all(r["status"] == "failed" and "not configured" in r["error"] for r in results)
    assert "DISCORD_WEBHOOK_URL" in next(r for r in results if r["platform"] == "discord")["error"]


def test_invalid_discord_webhook_is_reported_not_raised():
    service = build_posting_service({"DISCORD_WEBHOOK_URL": "https://evil.example/api/webhooks/1/2"})
    assert isinstance(service.adapters["discord"], UnconfiguredAdapter)


def test_http_only_mastodon_url_rejected():
    service = build_posting_service({"MASTODON_BASE_URL": "http://m.example", "MASTODON_ACCESS_TOKEN": "t"})
    assert isinstance(service.adapters["mastodon"], UnconfiguredAdapter)


def test_posting_platforms_selects_subset_ignores_unknown():
    s = load_settings({"POSTING_PLATFORMS": "Mastodon, bluesky, nope, mastodon"})
    assert s.platforms == ("mastodon", "bluesky")


def test_bad_timeout_falls_back():
    assert load_settings({"POSTING_TIMEOUT_SECONDS": "abc"}).platform_timeout_seconds == 30.0


def test_invalid_bluesky_pds_url_is_rejected():
    service = build_posting_service({
        "BLUESKY_HANDLE": "demo.bsky.social",
        "BLUESKY_APP_PASSWORD": "app-password",
        "BLUESKY_PDS_URL": "http://bsky.example",
    })
    assert isinstance(service.adapters["bluesky"], UnconfiguredAdapter)


def test_https_base_url_rejects_embedded_credentials_and_invalid_port():
    from app.services.factory import _https

    assert not _https("https://user:pass@matrix.example")
    assert not _https("https://matrix.example:99999")
    assert not _https("https:///missing-host")
    assert _https("https://matrix.example")


def test_unknown_only_platform_selection_does_not_enable_every_destination():
    settings = load_settings({"POSTING_PLATFORMS": "mastodoon, unknown"})
    assert settings.platforms == ()
