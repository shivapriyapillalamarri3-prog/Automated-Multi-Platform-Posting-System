import asyncio
from datetime import datetime, timezone

import httpx

from app.errors import PlatformError
from app.platforms.base import PlatformAdapter, PublishedPost
from app.services.posting_service import PostingService

SECRET_URL = "https://discord.com/api/webhooks/123/SUPER-SECRET-TOKEN"


class Fake(PlatformAdapter):
    def __init__(self, name, *, post=None, exc=None, delay=0.0):
        super().__init__()
        self.name, self._post, self._exc, self._delay = name, post, exc, delay

    async def publish(self, message):
        await asyncio.sleep(self._delay)
        if self._exc:
            raise self._exc
        return self._post or PublishedPost(
            "https://example.com/post/1", "1", True,
            datetime(2026, 11, 15, 10, 30, 0, tzinfo=timezone.utc),
        )


async def test_success_result_matches_spec_fields():
    [r] = await PostingService({"a": Fake("a")}).publish_all("m https://example.com")
    assert r == {
        "platform": "a", "status": "success", "posted_url": "https://example.com/post/1",
        "public_access": True, "date": "2026-11-15", "time": "10:30:00", "error": None,
    }


async def test_one_failure_does_not_stop_the_others_and_order_is_kept():
    service = PostingService({
        "a": Fake("a"), "b": Fake("b", exc=PlatformError("Authentication failed")), "c": Fake("c"),
    })
    results = await service.publish_all("m https://example.com")
    assert [r["platform"] for r in results] == ["a", "b", "c"]
    assert [r["status"] for r in results] == ["success", "failed", "success"]
    failed = results[1]
    assert failed["error"] == "Authentication failed"
    assert failed["public_access"] is False
    assert failed["posted_url"] is failed["date"] is failed["time"] is None


async def test_http_errors_never_leak_the_request_url():
    request = httpx.Request("POST", SECRET_URL + "?wait=true")
    exc = httpx.HTTPStatusError("boom " + SECRET_URL, request=request, response=httpx.Response(401, request=request))
    [r] = await PostingService({"discord": Fake("discord", exc=exc)}).publish_all("x")
    assert "SECRET" not in r["error"] and "webhooks" not in r["error"]
    assert "401" in r["error"]


async def test_unexpected_exception_is_generic():
    [r] = await PostingService({"a": Fake("a", exc=RuntimeError("password=hunter2"))}).publish_all("x")
    assert "hunter2" not in r["error"]
    assert r["status"] == "failed"


async def test_slow_platform_times_out_without_blocking_others():
    service = PostingService({"slow": Fake("slow", delay=5), "fast": Fake("fast")}, timeout_seconds=0.05)
    slow, fast = await service.publish_all("x")
    assert slow["status"] == "failed" and "timed out" in slow["error"]
    assert fast["status"] == "success"


async def test_note_is_reported_in_error_field_for_unverifiable_posts():
    post = PublishedPost("u", "1", False, datetime.now(timezone.utc), note="Posted; login required")
    [r] = await PostingService({"a": Fake("a", post=post)}).publish_all("x")
    assert r["status"] == "success" and r["public_access"] is False
    assert r["error"] == "Posted; login required"
