import pytest
from pydantic import ValidationError

from app.schemas import PostingRequest


def test_valid_request_is_stripped():
    assert PostingRequest(message="  Hello https://example.com ").message == "Hello https://example.com"


@pytest.mark.parametrize("message", [
    "A" * 201 + " https://example.com", "no link", "two https://a.com https://b.com", "bad http://x",
])
def test_invalid_messages_rejected(message):
    with pytest.raises(ValidationError):
        PostingRequest(message=message)


def test_platform_selection_is_internal_so_extra_fields_are_rejected():
    with pytest.raises(ValidationError):
        PostingRequest(message="Hi https://example.com", platforms=["bluesky"])
