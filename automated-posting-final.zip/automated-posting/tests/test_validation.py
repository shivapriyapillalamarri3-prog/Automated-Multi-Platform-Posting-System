import pytest

from app.validation import MessageValidationError, extract_cta_url, validate_message


def test_valid_message_is_returned_stripped():
    assert validate_message("  Hello https://example.com  ") == "Hello https://example.com"


def test_exactly_200_chars_ok_and_201_rejected():
    url = " https://example.com"
    assert validate_message("A" * (200 - len(url)) + url)
    with pytest.raises(MessageValidationError, match="200"):
        validate_message("A" * (201 - len(url)) + url)


@pytest.mark.parametrize("message", ["", "   ", "\n\t"])
def test_blank_rejected(message):
    with pytest.raises(MessageValidationError, match="empty"):
        validate_message(message)


@pytest.mark.parametrize("message", [
    "No link here",
    "Two https://a.example.com and https://b.example.com",
    "Same twice https://example.com https://example.com",
    "Mixed https://example.com and www.other.com",
])
def test_requires_exactly_one_link(message):
    with pytest.raises(MessageValidationError, match="exactly one"):
        validate_message(message)


def test_bare_www_link_asks_for_scheme():
    with pytest.raises(MessageValidationError, match="http"):
        validate_message("Visit www.example.com today")


def test_www_inside_https_url_counts_once():
    assert validate_message("Go https://www.example.com/path now")


@pytest.mark.parametrize("url", [
    "http://x",                       # no TLD
    "http://localhost:4000/admin",
    "http://127.0.0.1/",
    "http://169.254.169.254/latest",  # cloud metadata address
    "http://192.168.1.10/",
    "http://a..b",
    "http://myhost.local/",
    "https://user:pass@example.com",
    "https://example.com:99999",
    "https://example.com:0",
    "https://-bad-.example.com",
    "https://example.123",
])
def test_bad_urls_rejected(url):
    with pytest.raises(MessageValidationError):
        validate_message(f"Look {url} now")


@pytest.mark.parametrize("url", [
    "https://example.com",
    "HTTPS://EXAMPLE.COM/Path?q=1#frag",
    "http://example.co.uk:8080/a/b",
    "https://8.8.8.8/",
    "https://exämple.com",            # IDN hostname
])
def test_good_urls_accepted(url):
    assert validate_message(f"Look {url} now")


def test_trailing_punctuation_is_not_part_of_url():
    assert extract_cta_url("Visit (https://example.com/page).") == "https://example.com/page"
    assert validate_message("Visit https://example.com!")
